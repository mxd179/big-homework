import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox, QPushButton, QListWidget
from search import sort_by_broken, search_by_cin, filter_by_tag, sort_by_price, filter_by_sale
from Book import *  # 假设 Book 类在单独的文件中定义

class BookSearchApp(QWidget):
    def __init__(self):
        super().__init__()
        # 初始化界面
        self.initUI()
        # 模拟书籍数据
        
        self.books = Book.get_all()

    def initUI(self):
        # 创建垂直布局
        main_layout = QVBoxLayout()

        # 搜索类型选择部分
        search_type_layout = QHBoxLayout()
        search_type_label = QLabel("搜素模式:")
        self.search_type_combobox = QComboBox()
        search_types = [ "书号/书名搜索", "标签过滤", "低价优先","新书优先", "只看待售"]
        self.search_type_combobox.addItems(search_types)
        search_type_layout.addWidget(search_type_label)
        search_type_layout.addWidget(self.search_type_combobox)
        main_layout.addLayout(search_type_layout)

        # 搜索输入部分
        search_input_layout = QHBoxLayout()
        search_input_label = QLabel("输入:")
        self.search_input = QLineEdit()
        search_input_layout.addWidget(search_input_label)
        search_input_layout.addWidget(self.search_input)
        main_layout.addLayout(search_input_layout)

        # 搜索按钮部分
        search_button = QPushButton("搜索")
        search_button.clicked.connect(self.perform_search)
        main_layout.addWidget(search_button)

        # 搜索结果显示部分
        self.result_list = QListWidget()
        main_layout.addWidget(self.result_list)

        # 设置主布局
        self.setLayout(main_layout)

        # 设置窗口属性
        self.setWindowTitle('二手书查询')
        self.setGeometry(300, 300, 700, 600)
        self.show()

    def perform_search(self):
        # 清空之前的搜索结果
        self.result_list.clear()
        # 获取用户选择的搜索类型
        search_type = self.search_type_combobox.currentText()
        # 获取用户输入的搜索关键词
        search_input = self.search_input.text()

        if search_type == "新书优先":
            # 按标签搜索
            
            results = sort_by_broken(self.books)
        elif search_type == "书号/书名搜索":
            # 按关键词或 ID 搜索
            try:
                cinwords = int(search_input)
            except ValueError:
                cinwords = search_input
            result = search_by_cin(cinwords, self.books)
            if result:
                results = [result]
            else:
                results = []
        elif search_type == "标签过滤":
            # 按标签筛选
            results = filter_by_tag(self.books, search_input)
        elif search_type == "低价优先":
            # 按价格排序
            results = sort_by_price(self.books)
        elif search_type == "只看待售":
            # 筛选在售卖的书
            results = filter_by_sale(self.books)
        else:
            results = []

        # 显示搜索结果
        for book in results:
            result_text = f"ID: {book.id}, Name: {book.name}, Tags: {book.tag}, Price: {book.price}, Sale: {book.sale}"
            self.result_list.addItem(result_text)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = BookSearchApp()
    sys.exit(app.exec_())