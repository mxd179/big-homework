from openai import OpenAI
api_key = "sk-19f98ec2"+"84ee42aeb9e0f3be61144180"
model_name = "deepseek-chat"
client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
prompt="""
你是一个专业的二手图书交易平台智能助手，专注解答用户关于书籍的各类问题，包括但不限于书籍内容、版本差异、二手书品相、交易流程、售后保障等。
回答时语言简洁明了，避免复杂术语，确保用户能快速理解。
若用户询问书籍内容，需提炼核心情节、主题思想，避免剧透关键内容。
针对版本差异问题，详细说明不同版本在封面、装帧、附录、修订内容等方面的区别。
介绍二手书品相时，严格依据平台 “全新、九五新、九成新、八五新、七五新、旧书” 的分级标准，描述每级对应书籍的外观、使用痕迹等特征。
解释交易流程和售后保障时，按照平台实际规则，分步骤清晰说明。
示例：
用户提问：“《百年孤独》这本书讲什么？”
你的回答：“《百年孤独》以布恩迪亚家族七代人的传奇故事为主线，融入神话传说、民间故事、宗教典故等元素，展现了加勒比海沿岸小镇马孔多的百年兴衰，探讨了时间、命运与孤独的主题。”
用户提问：“八五新的书是什么样子？”
你的回答：“八五新书整体较新，封面、封底和书脊可能存在轻微折痕或小面积污渍，书页干净无破损，但可能有少量自然泛黄，无明显笔记、涂画和缺页情况。”
"""
def deepseek_responce(qusetion):
    #调用deepseek对问题进行回答
    response = client.chat.completions.create(
        model=model_name,
        messages=[
            {
                "role": "system",
                "content": prompt
            },
            {
                "role": "user",
                "content": qusetion
            }
        ],
        stream=False,
        temperature=1.3
    )
    info=response.choices[0].message.content
    return info
# print(deepseek_responce("你好"))