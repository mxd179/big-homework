import numpy as np
from Book import *
from User import *
import difflib

def similar_r(str1, str2):
    """
    使用 difflib.SequenceMatcher 计算两个字符串的相似度
    
    :return: 相似度得分，范围从 0 到 1
    """
    matcher = difflib.SequenceMatcher(None, str1, str2)
    return matcher.ratio()
def get_all_tags(books):
    all_tags=[]
    for book in books:
        for t in book.tag:
            if t not in all_tags:
                all_tags.append(t)
    return all_tags
def sort_by_broken(books,n_search_books=6):
    def mycmp(book):
        return book.broken
    book_lst=[]
    for book in books:
        book_lst.append(book)
    book_lst.sort(key=lambda book: mycmp(book),reverse=True)
    book_re=book_lst[:n_search_books]
    return book_re
def search_by_cin(cinwords,books):
    def mycmp(book,cinwords):
        ans=similar_r(cinwords,book.name)
        for t in book.tag:
            ans+=similar_r(cinwords,t)/len(book.tag)
        return ans

    if isinstance(cinwords,int):
        for book in books:
            if cinwords==book.id:
                return book
    else:
        book_lst=[]
        for book in books:
            book_lst.append(book)
        book_lst.sort(key=lambda book: mycmp(book, cinwords),reverse=True)
        return book_lst[0]
def filter_by_tag(books,tag):
    booklst=[]
    for book in books:
        if tag in book.tag:
            booklst.append(book)
    return booklst
def sort_by_price(books):
    booklst=[]
    for book in books:
        booklst.append(book)
    booklst.sort(key=lambda book:book.price)
    return booklst
def filter_by_sale(books):
    booklst=[]
    for book in books:
        if book.sale==1:
            booklst.append(book)
    return booklst


    
