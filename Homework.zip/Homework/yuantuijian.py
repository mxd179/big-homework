import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_distances
from collections import defaultdict
from Book import *
from User import *
def similarity_calculation(users,books):
    '''不用构造tag，直接根据大数据推荐的一种可行算法。变量为User和Book中的所有成员'''
    similarities={}
    users_id=[]
    books_id=[]
    records=[]
    for book in books:
        books_id.append(book.id)
    for user in users:
        users_id.append(user.id)
        buy_linear=[]
        for book in books:
            if book in user.buyrecords:
                buy_linear.append(int(1))
            else:
                buy_linear.append(int(0))
        records.append(buy_linear)
        '''这里buy_linear是一个n*1的向量，仅由0和1构成'''

    
    df=pd.DataFrame(data=records,index=users_id,columns=books_id)
    for i in books_id:
        for j in books_id:
            if i!=j:
                similarities[(i,j)]=df[i].T@df[j]/len(books_id)
    return similarities

def recommend_books(books,user_data,user_id,n_rec_books=10):
    '''推荐算法，变量为：
    user_data:包含用户购书记录的列表，组成元素为书的id（有时间可以考虑变成点击这本书的次数，上同）
    user_id:用户id
    n-rec_books:常量，推荐书的本数'''
    rec_books=[]
    books_id=[]
    for book in books:
        books_id.append(book.id)
    lst=np.zeros_like(user_data)
    if  np.array_equal(user_data, lst):
        N=len(books_id)
        rand=np.random.choice(range(0, N), size=n_rec_books, replace=False)
        return rand
    user_sim=[]
    for j in books_id:
        if j not in user_data:
            book_sim=0
            for i in user_data:
                book_sim+=similarities[(i,j)]
            user_sim.append((book_sim,j))
    user_sim=user_sim.sort(reverse=True)
    if len(user_sim)==0:
        N=len(books_id)
        rand=np.random.choice(range(0, N), size=n_rec_books, replace=False)
        return rand

    for i in range(n_rec_books):
        rec_books.append(user_sim[i][1])
    return rec_books

if __name__=="__main__":
    BOOK_FILE_PATH = "./data/Books.json"
    with open(BOOK_FILE_PATH,'r',encoding='utf-8')as file:
        books=[dict_to_book(i)for i in js.load(file)]
    USER_FILE_PATH = "./data/Users.json"
    with open(USER_FILE_PATH,'r',encoding='utf-8')as file:
        users=[dict_to_user(i) for i in js.load(file)["user"]]
    similarities=similarity_calculation(users,books)
    i,j=map(int,input().split())
    print(similarities[(i,j)])
  
    user_id=int(input())
    for user in users:
        if user.id==user_id:
            record=user.buyrecords
            break
    rec_books=recommend_books(books,record,user_id)
    print(rec_books)