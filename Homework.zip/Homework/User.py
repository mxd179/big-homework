import numpy as np
from Book import *
import json
import os
USER_FILE_PATH = "./data/Users.json"
def dict_to_user(item):
    user = User(item['account'], item['password'],
                [dict_to_book(i) for i in item['buyrecords']],
                [dict_to_book(i) for i in item['sellrecords']],
                [dict_to_book(i) for i in item['lovebook']],
                1, item['contact'])
    user.id = item['id']
    return user
def users_get():
    with open(USER_FILE_PATH,'r',encoding='utf-8') as f:
        try:
            print("读取Users.json成功")
            users_data=json.load(f)
            user_list = users_data.get('user', [])
        except Exception as e:
            print(e)
            print("打开Users.json失败")
            user_list=[]
    Users = []
    for item in user_list:
        new_user = dict_to_user(item)
        new_user.id = item['id']
        Users.append(new_user)
    return Users


class User:
    """
    用户类，包含账号，密码，推荐向量，
    """
    def __init__(self, account, password, buyrecords:list, sellrecords:list, love_book:list, dim, contact):
        self.account=account  #账号
        self.password=password #密码
        self.array=np.ones(dim)  #推荐向量
        self.buyrecords=buyrecords #购书记录
        self.sellrecords=sellrecords #出书记录
        self.love_book=love_book  #收藏
        self.contact=contact #联系方式
        self.id=None
    def sellbook(self,book:Book):
        book.sell=1
        book.account=self.account
        book.information=self.contact
        self.sellrecords.append(book)
    def buybook(self,book:Book):
        book.sell=0
        book.account=''
        book.information=''
        self.buyrecords.append(book)
    def love(self,book:Book):
        self.love_book.append(book)
    def users_store(self):
        """保存用户数据到JSON文件"""
        # 确保数据目录存在
        os.makedirs(os.path.dirname(USER_FILE_PATH), exist_ok=True)

        # 读取现有用户数据
        try:
            with open(USER_FILE_PATH, 'r', encoding='utf-8') as f:
                users_data = json.load(f)
        except FileNotFoundError:
            users_data = {'user_count': 0, 'user': []}
        except json.JSONDecodeError:
            print(f"错误：{USER_FILE_PATH} 不是有效的JSON文件，将创建新文件")
            users_data = {'user_count': 0, 'user': []}

        # 准备当前用户的数据
        user_dict = {
            'id':self.id,
            'account': self.account,
            'password': self.password,
            'buyrecords': [book.to_dict() for book in self.buyrecords],
            'sellrecords': [book.to_dict() for book in self.sellrecords],
            'lovebook': [book.to_dict() for book in self.love_book],
            'contact': self.contact
        }

        user_list = users_data.get('user', [])

        # 如果是新用户（ID为None），分配新ID并更新计数
        if self.id is None:
            self.id = users_data.get('user_count', 0)
            user_dict['id']=self.id
            users_data['user_count'] = self.id + 1
            user_list.append(user_dict)
        else:
            # 更新现有用户
            while self.id >= len(user_list):
                user_list.append({})
            user_list[self.id] = user_dict

        # 写回文件
        try:
            with open(USER_FILE_PATH, 'w', encoding='utf-8') as f:
                json.dump(users_data, f, indent=4, ensure_ascii=False)
            print(f"用户数据已成功保存到 {USER_FILE_PATH}，当前用户总数: {users_data['user_count']}")
        except Exception as e:
            print(f"保存用户数据失败: {e}")



