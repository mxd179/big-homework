import sys
import json
from Book import Book
from User import User
from Windows import *


if __name__ == '__main__':
    # 确保中文显示正常
    import matplotlib
    matplotlib.use('Agg')
    app = QApplication(sys.argv)
    # 设置全局字体
    font = QFont("SimHei")
    app.setFont(font)
    window = MainWindow()
    window.show()

    sys.exit(app.exec_())