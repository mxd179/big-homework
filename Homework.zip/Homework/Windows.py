import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QTimer
# from User import users_get
from Book import Book
from User import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import os
import shutil
import uuid
from PyQt5.QtGui import QPixmap, QFont
from search_ui import BookSearchApp
from deepseek import deepseek_responce
from recommend import recommend_books
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QGridLayout, QPushButton, QInputDialog,QSizePolicy,QMessageBox,QScrollArea,QGroupBox,QDialog,QFileDialog,QButtonGroup,QRadioButton,QMainWindow

users=users_get()

class LoginWindow(QWidget):
    """
    登录界面窗口，输入账号密码判断是否可以登入，无账号可以注册
    """

    # 主色调
    PRIMARY_COLOR = "#94070A"
    # 次要颜色
    SECONDARY_COLOR = "#F5F5F5"
    # 强调色
    ACCENT_COLOR = "#D32F2F"
    # 中性色
    NEUTRAL_COLOR = "#333333"

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # 设置窗口大小和位置
        self.setFixedSize(400, 300)
        self.center_window()

        # 设置窗口样式
        self.setStyleSheet(f"""
            QWidget {{
                background-color: white;
            }}
            QLabel {{
                color: {self.NEUTRAL_COLOR};
                font-size: 14px;
            }}
            QLineEdit {{
                border: 1px solid #CCCCCC;
                border-radius: 4px;
                padding: 8px;
                font-size: 14px;
            }}
            QLineEdit:focus {{
                border: 1px solid {self.PRIMARY_COLOR};
                outline: none;
            }}
            QPushButton {{
                background-color: {self.PRIMARY_COLOR};
                color: white;
                border-radius: 4px;
                padding: 10px;
                font-size: 14px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {self.ACCENT_COLOR};
            }}
            QPushButton:pressed {{
                background-color: #7A0507;
            }}
            QMessageBox {{
                font-size: 14px;
            }}
        """)

        # 创建主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(30, 30, 30, 30)
        main_layout.setSpacing(20)

        # 标题
        title_label = QLabel("书香博雅二手书交易平台")
        title_font = QFont()
        title_font.setPointSize(20)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet(f"color: {self.PRIMARY_COLOR};")
        main_layout.addWidget(title_label)

        # 分隔线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        line.setStyleSheet("border: 1px solid #CCCCCC;")
        main_layout.addWidget(line)

        # 账号和密码输入区域
        form_layout = QGridLayout()
        form_layout.setSpacing(15)

        # 账号
        self.account_label = QLabel('账号:')
        self.account_edit = QLineEdit()
        self.account_edit.setEchoMode(QLineEdit.Normal)
        self.account_edit.setPlaceholderText("请输入账号")

        # 密码
        self.password_label = QLabel('密码:')
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText("请输入密码")

        form_layout.addWidget(self.account_label, 0, 0)
        form_layout.addWidget(self.account_edit, 0, 1)
        form_layout.addWidget(self.password_label, 1, 0)
        form_layout.addWidget(self.password_edit, 1, 1)

        main_layout.addLayout(form_layout)

        # 按钮区域
        self.button_layout = QHBoxLayout()
        self.button_layout.setSpacing(15)

        self.login_button = QPushButton("登录")
        self.login_button.setMinimumHeight(40)
        self.login_button.setCursor(Qt.PointingHandCursor)
        # self.login_button.clicked.connect(self.go_to_mainwindow)

        self.create_button = QPushButton("注册")
        self.create_button.setMinimumHeight(40)
        self.create_button.setCursor(Qt.PointingHandCursor)
        self.create_button.clicked.connect(self.create_user)

        self.button_layout.addWidget(self.login_button)
        self.button_layout.addWidget(self.create_button)

        main_layout.addLayout(self.button_layout)

        # 版权信息
        copyright_label = QLabel("© 2025 二手书交易平台")
        copyright_label.setAlignment(Qt.AlignCenter)
        copyright_label.setStyleSheet("color: #888888; font-size: 12px;")
        main_layout.addWidget(copyright_label)

    def center_window(self):
        """将窗口居中显示"""
        frame_geometry = self.frameGeometry()
        center_point = QApplication.primaryScreen().availableGeometry().center()
        frame_geometry.moveCenter(center_point)
        self.move(frame_geometry.topLeft())

    def go_to_mainwindow(self):
        account = self.account_edit.text()
        password = self.password_edit.text()
        flag = 1
        for item in users:
            if account == item.account:
                flag = 0
                if password == item.password:
                    self.hide()
                else:
                    self.show_message("错误", "密码错误")
        if flag == 1:
            self.show_message("错误", "账号不存在")

    def create_user(self):
        text, ok = QInputDialog.getText(self, '注册', '请输入账号：')
        if ok and text:
            flag = 1
            for user in users:
                if text == user.account:
                    flag = 0
                    self.show_message("提示", "账号已存在！")
            if flag:
                text2, ok2 = QInputDialog.getText(self, '注册', '请输入密码')
                if ok2 and text2:
                    self.show_message('欢迎', f'注册成功！\n账号：{text}, 密码：{text2}')
                    new_user = User(text, text2, [], [], [], 10, [])
                    users.append(new_user)
                    new_user.users_store()

    def show_message(self, title, message):
        """显示消息对话框"""
        dialog = QMessageBox(self)
        dialog.setFixedSize(200,150)
        dialog.setWindowTitle(title)
        dialog.setText(message)
        dialog.setStandardButtons(QMessageBox.Yes)
        dialog.setStyleSheet(f"""
            QMessageBox {{
                background-color: white;
                border: 1px solid #CCCCCC;
                border-radius: 4px;
            }}
            QLabel {{
                color: {self.NEUTRAL_COLOR};
                font-size: 14px;
                padding: 10px;
            }}
            QPushButton {{
                background-color: {self.PRIMARY_COLOR};
                color: white;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 14px;
                min-width: 80px;
            }}
            QPushButton:hover {{
                background-color: {self.ACCENT_COLOR};
            }}
            QPushButton:pressed {{
                background-color: #7A0507;
            }}
        """)
        dialog.show()


books=Book.get_all()
# test_books = Book.get_all()
# test_user = users_get()[0]

# test_books[4].sale=1
# for i in range(5):
#     if i < len(test_books):
#         test_user.sellrecords.append(test_books[i])
# test_user.buyrecords.extend(test_books)



class BookItem(QWidget):
    """图书展示项组件"""

    def __init__(self, book, parent=None):
        super().__init__(parent)
        self.book = book
        self.user=None
        # print(self.book)
        self.initUI()

    def initUI(self):
        # 使用主布局管理整体结构
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(15)

        # 创建图片容器，使用固定尺寸并居中显示图片
        image_container = QWidget()
        image_container.setFixedSize(160, 200)  # 固定图片区域大小
        image_layout = QVBoxLayout(image_container)
        image_layout.setContentsMargins(0, 0, 0, 0)
        image_layout.setAlignment(Qt.AlignCenter)

        # 书籍图片
        self.img_label = QLabel()
        self.img_label.setAlignment(Qt.AlignCenter)
        self.img_label.setFixedSize(120, 160)  # 固定标签大小
        self.load_image()  # 单独方法加载图片

        image_layout.addWidget(self.img_label)
        main_layout.addWidget(image_container)

        # 书籍信息区域
        info_layout = QVBoxLayout()
        info_layout.setSpacing(8)
        conditions = ["全新", "九五新", "九成", "八五新", "七五新", "七成新及以下"]
        name_label = QLabel(f"<b>{self.book.name}</b>")
        name_label.setWordWrap(True)
        price_label = QLabel(f"价格: ¥{float(self.book.price):.2f}")
        # print(self.book)
        broken_label = QLabel(f"状态: {conditions[self.book.broken]}")

        info_layout.addWidget(name_label)
        info_layout.addWidget(price_label)
        info_layout.addWidget(broken_label)

        # 标签显示
        tags_layout = QHBoxLayout()
        tags_layout.setSpacing(5)
        tags_layout.setAlignment(Qt.AlignLeft)

        for tag in self.book.tag[:3]:  # 限制显示标签数量
            tag_label = QLabel(tag)
            tag_label.setStyleSheet(
                "background-color: #E3F2FD; color: #1976D2; padding: 2px 8px; border-radius: 4px; font-size: 12px;")
            tag_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            tags_layout.addWidget(tag_label)

        info_layout.addLayout(tags_layout)
        info_layout.addStretch()

        main_layout.addLayout(info_layout, 1)  # 信息区域扩展填充剩余空间

        # 设置整体尺寸策略

        # 按钮区域
        btn_layout = QHBoxLayout()
        if self.book.sale:
            sold_label = QLabel("已售出")
            sold_label.setStyleSheet("color: #999999; font-style: italic;")
            btn_layout.addWidget(sold_label)
        else:
            buy_btn = QPushButton("简介")
            buy_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 3px;")
            # buy_btn.setFixedSize(100, 25)
            buy_btn.clicked.connect(self.contact_seller)
            btn_layout.addWidget(buy_btn)
        love_btn=QPushButton("感兴趣")
        love_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 3px;")
        love_btn.clicked.connect(self.lovebook)
        
        btn_layout.addStretch()
        info_layout.addLayout(btn_layout)

        info_layout.addStretch()
        main_layout.addLayout(info_layout, 1)

        # 设置边框和边距
        self.setStyleSheet("""
            QWidget {
                border: 1px solid #E0E0E0;
                border-radius: 5px;
                padding: 5px;
                margin: 5px;
            }
            QWidget:hover {
                border: 1px solid #94070A;
            }
        """)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
    
    def lovebook(self):
        self.user.love_book.append(self.book)
    
    def contact_seller(self):
        QMessageBox.information(self, "简介",
                                f"卖家{self.book.account}留下的简介：{self.book.information}")

    def load_image(self):
        """加载并显示图片，处理可能的加载失败情况"""
        try:
            pixmap = QPixmap(self.book.image_path)

            if pixmap.isNull():
                raise Exception("图片为空")

            # 使用平滑缩放保持图片质量
            scaled_pixmap = pixmap.scaled(
                100, 140,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )

            self.img_label.setPixmap(scaled_pixmap)

        except Exception as e:
            print(f"图片加载失败: {e}")
            # 显示默认图片或错误提示
            self.img_label.setText("暂无图片")
            self.img_label.setStyleSheet("border: 1px solid #CCCCCC; background-color: #F5F5F5;")
class HomePage(QWidget):
    """主页"""

    def __init__(self, mainwindow,books, parent=None):
        super().__init__(parent)
        self.user = mainwindow.user
        self.books = books
        self.initUI()

    def initUI(self):
        # 创建主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # 搜索区域
        search_layout = QHBoxLayout()
        search_layout.setSpacing(10)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜索书籍...")
        self.search_input.setMinimumHeight(35)
        self.search_input.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 5px; padding: 0 10px;")
        search_layout.addWidget(self.search_input, 8)

        search_btn = QPushButton("搜索")
        search_btn.setMinimumHeight(35)
        search_btn.setStyleSheet("background-color:#94070A; color: white; border-radius: 5px;")
        search_btn.clicked.connect(self.search_books)
        search_layout.addWidget(search_btn, 2)

        question_btn=QPushButton("图书查询")
        question_btn.setMinimumHeight(35)
        question_btn.setMaximumWidth(100)
        question_btn.setStyleSheet("background-color:#94070A; color: white; border-radius: 5px;")
        question_btn.clicked.connect(self.open_search_window)
        search_layout.addWidget(question_btn,3)
        main_layout.addLayout(search_layout)

        # 分类筛选
        category_layout = QHBoxLayout()
        category_layout.setSpacing(10)

        category_label = QLabel("分类:")
        category_layout.addWidget(category_label)

        self.category_btns = []
        categories = ["全部", "编程开发", "文学小说", "历史传记", "科学技术", "心理学", "经济学", "艺术设计"]
        for category in categories:
            btn = QPushButton(category)
            btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #333333;
                    border-radius: 5px;
                    padding: 5px 10px;
                }
                QPushButton:checked {
                    background-color: #94070A;
                    color: white;
                }
            """)
            if category == "全部":
                btn.setChecked(True)
            btn.clicked.connect(lambda checked, c=category: self.filter_books(c))
            category_layout.addWidget(btn)
            self.category_btns.append(btn)

        category_layout.addStretch()
        main_layout.addLayout(category_layout)

        # 推荐图书区域
        recommended_label = QLabel("推荐图书")
        font = recommended_label.font()
        font.setBold(True)
        font.setPointSize(14)
        recommended_label.setFont(font)
        main_layout.addWidget(recommended_label)

        # 图书网格布局
        self.books_grid = QGridLayout()
        self.books_grid.setSpacing(10)
        self.books_grid.setColumnStretch(3, 1)

        # 创建滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_content.setLayout(self.books_grid)
        scroll_area.setWidget(scroll_content)

        main_layout.addWidget(scroll_area, 1)

        # 初始化显示所有书籍
        boughtbooks=[]
        for book in self.user.buyrecords:
            boughtbooks.append(book)
        re_books=recommend_books(boughtbooks,self.user.id,20)
        self.display_books(self.books)

    def display_books(self, books):
        # 清空现有书籍
        for i in reversed(range(self.books_grid.count())):
            self.books_grid.itemAt(i).widget().setParent(None)

        # 显示书籍
        row = 0
        col = 0
        for book in books:
            book_item = BookItem(book)
            self.books_grid.addWidget(book_item, row, col)
            col += 1
            if col >= 2:
                col = 0
                row += 1

    def search_books(self):
        keyword = self.search_input.text().strip().lower()
        if not keyword:
            self.display_books(self.books)
            return

        # 搜索匹配的书籍
        result = []
        for book in self.books:
            if keyword in book.name.lower() or any(keyword in tag.lower() for tag in book.tag):
                result.append(book)

        self.display_books(result)

    def filter_books(self, category):
        # 重置所有按钮状态
        for btn in self.category_btns:
            btn.setChecked(False)

        # 设置当前按钮为选中状态
        for btn in self.category_btns:
            if btn.text() == category:
                btn.setChecked(True)
                break

        # 筛选书籍
        if category == "全部":
            self.display_books(self.books)
        else:
            result = []
            for book in self.books:
                if category in book.tag:
                    result.append(book)
            self.display_books(result)

    def open_search_window(self):
        self.search_window=BookSearchApp()
        self.search_window.show()
class SellBookPage(QWidget):
    """卖书页面"""

    # 图片保存的基础目录
    IMAGE_DIR = "image"

    def __init__(self, mainwindow, parent=None):
        super().__init__(parent)
        self.user = mainwindow.user
        self.selected_tags = []
        self.image_path = ""
        self.saved_image_path = ""  # 保存到本地后的图片路径
        self.initUI()

        # 确保图片保存目录存在
        os.makedirs(self.IMAGE_DIR, exist_ok=True)

    def initUI(self):
        # 创建主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # 表单标题
        title_label = QLabel("发布二手书籍")
        font = title_label.font()
        font.setBold(True)
        font.setPointSize(16)
        title_label.setFont(font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)

        # 分隔线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # 表单布局
        form_layout = QGridLayout()
        form_layout.setSpacing(15)
        form_layout.setColumnStretch(1, 1)

        # 书名
        form_layout.addWidget(QLabel("书名:"), 0, 0)
        self.name_input = QLineEdit()
        form_layout.addWidget(self.name_input, 0, 1)

        # 价格
        form_layout.addWidget(QLabel("价格:"), 1, 0)
        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText("请输入价格（元）")
        form_layout.addWidget(self.price_input, 1, 1)

        # 崭新程度
        form_layout.addWidget(QLabel("崭新程度:"), 2, 0)
        broken_layout = QHBoxLayout()

        self.broken_group = QButtonGroup(self)
        brokens = ["全新", "九五新", "九成", "八五新", "七五新", "七成新及以下"]

        for i, broken in enumerate(brokens):
            radio = QRadioButton(broken)
            broken_layout.addWidget(radio)
            self.broken_group.addButton(radio, i)

            if i == 2:  # 默认选择"九新"
                radio.setChecked(True)

        form_layout.addLayout(broken_layout, 2, 1)

        # 图片与标签并排区域
        image_tag_layout = QHBoxLayout()

        # 上传图片（左侧）
        image_group = QGroupBox("书籍图片")
        image_group.setMinimumWidth(150)
        upload_layout = QVBoxLayout(image_group)

        self.image_label = QLabel()
        self.image_label.setFixedSize(120, 160)
        self.image_label.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 5px;")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setText("点击上传图片")
        self.image_label.mousePressEvent = self.upload_image
        upload_layout.addWidget(self.image_label)

        upload_layout.addStretch()
        image_group.setLayout(upload_layout)
        image_tag_layout.addWidget(image_group)

        # 右侧区域（简介和标签）
        right_side_layout = QVBoxLayout()

        # 书籍简介
        desc_group = QGroupBox("书籍简介")
        desc_layout = QVBoxLayout(desc_group)

        self.desc_input = QTextEdit()
        self.desc_input.setPlaceholderText("请输入书籍简介（记得留下联系方式）")
        self.desc_input.setMinimumHeight(80)
        self.desc_input.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 3px;")
        desc_layout.addWidget(self.desc_input)

        desc_group.setLayout(desc_layout)
        right_side_layout.addWidget(desc_group)

        # 已选标签显示（右侧，竖向滑动栏）
        tag_group = QGroupBox("已选标签")
        tag_layout = QVBoxLayout(tag_group)

        # 使用竖向排列的标签容器，带垂直滚动条
        self.tags_container = QWidget()
        self.tags_layout = QVBoxLayout(self.tags_container)
        self.tags_layout.setSpacing(5)
        self.tags_layout.setAlignment(Qt.AlignTop)
        self.tags_layout.setContentsMargins(5, 5, 5, 5)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(self.tags_container)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 3px;")
        scroll_area.setMinimumHeight(80)  # 调整高度

        tag_layout.addWidget(scroll_area)
        tag_group.setLayout(tag_layout)
        right_side_layout.addWidget(tag_group)

        right_side_layout.setStretch(0, 1)  # 简介占1份
        right_side_layout.setStretch(1, 1)  # 标签占1份

        image_tag_layout.addLayout(right_side_layout, 1)  # 右侧区域占满剩余空间

        form_layout.addLayout(image_tag_layout, 3, 0, 1, 2)  # 占据第3行两列

        # 标签输入与下拉区域
        form_layout.addWidget(QLabel("输入标签:"), 4, 0)

        input_layout = QHBoxLayout()
        self.tag_input = QLineEdit()
        self.tag_input.setPlaceholderText("输入标签并按回车添加")
        self.tag_input.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 3px;")
        self.tag_input.returnPressed.connect(self.add_tag)

        self.dropdown_btn = QPushButton("▼")
        self.dropdown_btn.setFixedSize(30, 35)
        self.dropdown_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                border: 1px solid #CCCCCC;
                border-radius: 0 3px 3px 0;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        self.dropdown_btn.clicked.connect(self.toggle_dropdown)

        input_layout.addWidget(self.tag_input, 1)
        input_layout.addWidget(self.dropdown_btn)
        form_layout.addLayout(input_layout, 4, 1)

        # 下拉标签选择区域
        self.dropdown_area = QWidget()
        self.dropdown_area.setMaximumHeight(200)
        self.dropdown_area.hide()

        self.dropdown_layout = QGridLayout(self.dropdown_area)
        self.dropdown_layout.setSpacing(5)
        self.dropdown_layout.setContentsMargins(5, 5, 5, 5)

        # 添加预设标签
        preset_tags = ["编程开发", "文学小说", "历史传记", "科学技术", "心理学",
                       "经济学", "艺术设计", "教育考试", "计算机", "数学", "英语", "哲学"]

        row = 0
        col = 0
        for tag in preset_tags:
            btn = QPushButton(tag)
            btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #333333;
                    border-radius: 5px;
                    padding: 5px 10px;
                }
                QPushButton:checked {
                    background-color: #94070A;
                    color: white;
                }
                QPushButton:hover {
                    background-color: #E0E0E0;
                }
            """)
            btn.clicked.connect(lambda checked, t=tag: self.select_preset_tag(t, checked))
            self.dropdown_layout.addWidget(btn, row, col)

            col += 1
            if col >= 4:
                col = 0
                row += 1

        # 添加滚动区域
        scroll_area_dropdown = QScrollArea()
        scroll_area_dropdown.setWidgetResizable(True)
        scroll_area_dropdown.setWidget(self.dropdown_area)
        scroll_area_dropdown.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area_dropdown.setStyleSheet("border: none;")
        form_layout.addWidget(scroll_area_dropdown, 5, 0, 1, 2)

        form_layout.addWidget(QLabel("提示: 可从下拉菜单选择标签或手动输入"), 6, 0, 1, 2)

        main_layout.addLayout(form_layout)

        # 分隔线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # 提交按钮
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(20)
        btn_layout.setContentsMargins(0, 20, 0, 0)

        submit_btn = QPushButton("发布书籍")
        submit_btn.setMinimumHeight(40)
        submit_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 5px; font-size: 14px;")
        submit_btn.clicked.connect(self.submit_book)
        btn_layout.addWidget(submit_btn)

        cancel_btn = QPushButton("取消")
        cancel_btn.setMinimumHeight(40)
        cancel_btn.setStyleSheet("background-color: #F5F5F5; color: #333333; border-radius: 5px; font-size: 14px;")
        cancel_btn.clicked.connect(self.clear_form)
        btn_layout.addWidget(cancel_btn)

        main_layout.addLayout(btn_layout)

    def upload_image(self, event):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择图片", "", "图片文件 (*.png *.jpg *.jpeg *.bmp)"
        )

        if file_path:
            self.image_path = file_path
            pixmap = QPixmap(file_path)
            scaled_pixmap = pixmap.scaled(120, 160, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(scaled_pixmap)
            # 重置保存的图片路径
            self.saved_image_path = ""

    def toggle_dropdown(self):
        """切换下拉菜单的显示/隐藏"""
        if self.dropdown_area.isVisible():
            self.dropdown_area.hide()
        else:
            self.dropdown_area.show()

    def select_preset_tag(self, tag, checked):
        """选择预设标签"""
        if checked:
            if tag not in self.selected_tags:
                self.selected_tags.append(tag)
                self.update_tags_display()
        else:
            if tag in self.selected_tags:
                self.selected_tags.remove(tag)
                self.update_tags_display()

    def add_tag(self):
        """添加手动输入的标签"""
        tag_text = self.tag_input.text().strip()
        if tag_text and tag_text not in self.selected_tags:
            self.selected_tags.append(tag_text)
            self.update_tags_display()
            self.tag_input.clear()
            # self.dropdown_area.hide()
            for i in range(self.dropdown_layout.count()):
                widget = self.dropdown_layout.itemAt(i).widget()
                if isinstance(widget, QPushButton) and widget.isCheckable():
                    widget.setChecked(widget.text() in self.selected_tags)

    def remove_tag(self, tag, widget):
        """移除标签"""
        if tag in self.selected_tags:
            self.selected_tags.remove(tag)
            self.update_tags_display()
            for i in range(self.dropdown_layout.count()):
                widget = self.dropdown_layout.itemAt(i).widget()
                if isinstance(widget, QPushButton) and widget.isCheckable():
                    widget.setChecked(widget.text() in self.selected_tags)

    def update_tags_display(self):
        """更新标签显示区域"""
        # 清空现有标签
        while self.tags_layout.count():
            item = self.tags_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.setParent(None)

        # 添加所有选中的标签
        for tag in self.selected_tags:
            tag_widget = QWidget()
            tag_layout = QHBoxLayout(tag_widget)
            tag_layout.setContentsMargins(5, 2, 5, 2)
            tag_layout.setSpacing(5)

            tag_label = QLabel(tag)
            tag_label.setStyleSheet("color: white;")

            remove_btn = QPushButton("×")
            remove_btn.setFixedSize(20, 20)
            remove_btn.setStyleSheet("""
                QPushButton {
                    background-color: #CC0000;
                    color: white;
                    border-radius: 10px;
                    padding: 0;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #FF0000;
                }
            """)
            remove_btn.clicked.connect(lambda checked, t=tag, w=tag_widget: self.remove_tag(t, w))

            tag_layout.addWidget(tag_label)
            tag_layout.addWidget(remove_btn)

            tag_widget.setStyleSheet("background-color: #94070A; border-radius: 15px;")
            self.tags_layout.addWidget(tag_widget)

        # 添加拉伸，使标签靠上显示
        self.tags_layout.addStretch()

    def save_image_to_local(self):
        """将上传的图片保存到本地文件夹"""
        if not self.image_path:
            return None

        try:
            # 获取文件扩展名
            file_ext = os.path.splitext(self.image_path)[1].lower()

            # 生成唯一文件名
            unique_filename = f"{uuid.uuid4().hex}{file_ext}"

            # 构建保存路径
            save_path = os.path.join(self.IMAGE_DIR, unique_filename)

            # 复制文件到保存路径
            shutil.copy2(self.image_path, save_path)

            return save_path

        except Exception as e:
            print(f"保存图片失败: {e}")
            return None

    def submit_book(self):
        # 验证表单
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "提示", "请输入书名")
            return

        price_text = self.price_input.text().strip()
        if not price_text:
            QMessageBox.warning(self, "提示", "请输入价格")
            return

        try:
            price = float(price_text)
            if price <= 0:
                raise ValueError
        except ValueError:
            QMessageBox.warning(self, "提示", "请输入有效的价格")
            return

        if not self.image_path:
            QMessageBox.warning(self, "提示", "请上传书籍图片")
            return

        if not self.selected_tags:
            QMessageBox.warning(self, "提示", "请至少添加一个标签")
            return

        # 获取选中的崭新程度
        checked_id = self.broken_group.checkedId()
        broken = checked_id if checked_id >= 0 else 2

        # 保存图片到本地
        self.saved_image_path = self.save_image_to_local()
        if not self.saved_image_path:
            QMessageBox.warning(self, "提示", "图片保存失败，请重试")
            return

        # 获取书籍简介
        information = self.desc_input.toPlainText().strip()
        #更新书籍信息
        # print(broken)
        new_book = Book(
            name=name,
            price=price,
            broken=broken,
            tag=self.selected_tags,
            account=self.user.account,
            sale=False,
            information=information,
            image_path=self.saved_image_path
        )
        new_book.save()
        self.user.sellrecords.append(new_book)
        self.user.users_store()
        QMessageBox.information(self, "成功", "书籍发布成功！")
        self.clear_form()

    def clear_form(self):
        """清空表单"""
        self.name_input.clear()
        self.price_input.clear()
        self.image_path = ""
        self.saved_image_path = ""  # 重置保存的图片路径
        self.image_label.setPixmap(QPixmap())
        self.image_label.setText("点击上传图片")
        # for i in range(self.broken_group.buttonCount()):
        #     self.broken_group.button(i).setChecked(i == 2)

        self.selected_tags = []
        self.update_tags_display()
        self.tag_input.clear()
        self.dropdown_area.hide()

        for i in range(self.dropdown_layout.count()):
            widget = self.dropdown_layout.itemAt(i).widget()
            if isinstance(widget, QPushButton) and widget.isCheckable():
                widget.setChecked(False)

        # 清空简介输入框
        self.desc_input.clear()
import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QTextEdit, QPushButton, QSplitter, QFrame)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QTextCursor, QFont


class HelpPage(QWidget):
    """问题咨询页面"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        # 创建主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # 标题
        title_label = QLabel("问题咨询")
        font = title_label.font()
        font.setBold(True)
        font.setPointSize(16)
        title_label.setFont(font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)

        # 分隔线
        line = QFrame(self)
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # 对话区域
        splitter = QSplitter(Qt.Vertical)

        # 问题和回答显示区域
        self.chat_display = QTextEdit(self)
        self.chat_display.setReadOnly(True)
        self.chat_display.setMinimumHeight(400)
        self.chat_display.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 5px; padding: 10px;")
        splitter.addWidget(self.chat_display)

        # 输入区域
        input_layout = QVBoxLayout()

        self.question_input = QTextEdit(self)
        self.question_input.setPlaceholderText("请输入您的问题，反应时间较长，期间可能会出现未响应的现象，请耐心等待")
        self.question_input.setMinimumHeight(100)
        self.question_input.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 5px; padding: 10px;")
        input_layout.addWidget(self.question_input)

        # 按钮区域
        btn_layout = QHBoxLayout(self)
        btn_layout.setSpacing(10)

        send_btn = QPushButton("发送")
        send_btn.setMinimumHeight(35)
        send_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 5px;")
        send_btn.clicked.connect(self.send_question)
        btn_layout.addWidget(send_btn)

        clear_btn = QPushButton("清空")
        clear_btn.setMinimumHeight(35)
        clear_btn.setStyleSheet("background-color: #F5F5F5; color: #333333; border-radius: 5px;")
        clear_btn.clicked.connect(self.clear_chat)
        btn_layout.addWidget(clear_btn)

        input_layout.addLayout(btn_layout)

        input_widget = QWidget(self)
        input_widget.setLayout(input_layout)
        splitter.addWidget(input_widget)

        # 设置分割器比例
        splitter.setSizes([400, 150])

        main_layout.addWidget(splitter, 1)

        # 添加常见问题
        self.add_faq()

    def add_faq(self):
        # 添加一些常见问题和回答
        faq_list = [
            ("如何发布二手书籍？",
             "您可以点击顶部导航栏中的“卖书”按钮，然后填写书籍信息并上传图片，最后点击“发布书籍”按钮即可。"),
            ("如何购买二手书籍？", "在主页浏览您感兴趣的书籍，点击“联系卖家”按钮，然后通过提供的联系方式与卖家协商交易。"),
            (
                "交易成功后如何标记书籍为已售出？",
                "在个人主页的“我的发布”中，找到已售出的书籍，点击“标记为已售出”按钮即可。"),
            ("如何修改已发布的书籍信息？",
             "在个人主页的“我的发布”中，找到需要修改的书籍，点击“编辑”按钮进行修改，完成后点击“保存”。"),
            ("如果遇到交易纠纷怎么办？", "请联系我们的客服，提供交易详情和相关证据，我们会协助您解决问题。")
        ]

        for question, answer in faq_list:
            self.append_message("Q: " + question, "blue")
            self.append_message("A: " + answer, "green")

    def send_question(self):
        question = self.question_input.toPlainText().strip()
        if not question:
            return

        # 添加用户问题
        self.append_message("Q: " + question, "blue")

        # 清空输入框
        self.question_input.clear()

        # 模拟的回答
        answer = deepseek_responce(question)

        # 延迟显示回答，模拟思考时间
        # 使用局部变量避免循环引用
        local_answer = answer
        QTimer.singleShot(1000, lambda: self.append_message("A: " + local_answer, "green"))

    def clear_chat(self):
        self.chat_display.clear()
        self.add_faq()

    def append_message(self, message, color):
        # 获取当前光标
        cursor = self.chat_display.textCursor()

        # 移动到文本末尾
        cursor.movePosition(QTextCursor.End)

        # 设置文本格式
        text_format = cursor.charFormat()
        if color == "blue":
            text_format.setForeground(QColor(30, 136, 229))  # 蓝色
        elif color == "green":
            text_format.setForeground(QColor(76, 175, 80))  # 绿色

        cursor.setCharFormat(text_format)

        # 插入文本
        cursor.insertText(message + "\n\n")

        # 更新文本编辑框
        self.chat_display.setTextCursor(cursor)
        self.chat_display.ensureCursorVisible()


class AddBoughtBookDialog(QDialog):
    """添加已买入书籍的对话框"""

    def __init__(self, parent=None, all_books=None, user=None):
        super().__init__(parent)
        self.setWindowTitle("添加已买入书籍")
        self.setMinimumSize(800, 600)

        self.all_books = all_books or []  # 所有可用书籍
        self.user = user  # 当前用户
        self.selected_books = []  # 选中要添加的书籍
        self.book_buttons = {}  # 跟踪书籍与按钮的映射

        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout(self)

        # 搜索区域
        search_layout = QHBoxLayout()
        search_layout.setSpacing(10)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜索书籍名称或标签...")
        self.search_input.setMinimumHeight(35)
        search_layout.addWidget(self.search_input, 8)

        search_btn = QPushButton("搜索")
        search_btn.setMinimumHeight(35)
        search_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 5px;")
        search_btn.clicked.connect(self.search_books)
        search_layout.addWidget(search_btn, 2)

        main_layout.addLayout(search_layout)

        # 书籍列表区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)

        self.books_container = QWidget()
        self.books_layout = QGridLayout(self.books_container)
        self.books_layout.setSpacing(10)
        self.books_layout.setColumnStretch(2, 1)

        scroll_area.setWidget(self.books_container)
        main_layout.addWidget(scroll_area, 1)

        # 底部按钮区域
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(20)

        add_btn = QPushButton("添加选中书籍")
        add_btn.setMinimumHeight(40)
        add_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 5px;")
        add_btn.clicked.connect(self.add_selected_books)
        btn_layout.addWidget(add_btn)

        cancel_btn = QPushButton("取消")
        cancel_btn.setMinimumHeight(40)
        cancel_btn.setStyleSheet("background-color: #F5F5F5; color: #333333; border-radius: 5px;")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)

        main_layout.addLayout(btn_layout)

        # 初始显示所有书籍
        self.display_books(self.all_books)

    def display_books(self, books):
        # 清空现有书籍
        self.book_buttons = {}  # 重置映射
        for i in reversed(range(self.books_layout.count())):
            self.books_layout.itemAt(i).widget().setParent(None)

        if not books:
            empty_label = QLabel("未找到匹配的书籍")
            empty_label.setAlignment(Qt.AlignCenter)
            empty_label.setStyleSheet("color: #999999; font-size: 14px; margin-top: 50px;")
            self.books_layout.addWidget(empty_label, 0, 0, 1, 3)
            return

        # 显示书籍
        row = 0
        col = 0
        for book in books:
            # 跳过用户已经买入的书籍
            if book in self.user.buyrecords:
                continue

            book_widget = QWidget()
            book_layout = QHBoxLayout(book_widget)
            book_layout.setContentsMargins(10, 10, 10, 10)

            # 书籍信息
            info_layout = QVBoxLayout()

            name_label = QLabel(f"<b>{book.name}</b>")
            name_label.setWordWrap(True)

            price_label = QLabel(f"价格: ¥{float(book.price):.2f}")
            conditions = ["全新", "九五新", "九成", "八五新", "七五新", "七成新及以下"]
            broken_label = QLabel(f"状态: {conditions[book.broken]}")

            info_layout.addWidget(name_label)
            info_layout.addWidget(price_label)
            info_layout.addWidget(broken_label)

            # 标签显示
            tags_layout = QHBoxLayout()
            tags_layout.setSpacing(5)
            tags_layout.setAlignment(Qt.AlignLeft)

            for tag in book.tag[:3]:  # 限制显示标签数量
                tag_label = QLabel(tag)
                tag_label.setStyleSheet(
                    "background-color: #E3F2FD; color: #1976D2; padding: 2px 8px; border-radius: 4px; font-size: 12px;")
                tag_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
                tags_layout.addWidget(tag_label)

            info_layout.addLayout(tags_layout)

            # 选择按钮
            select_btn = QPushButton("选择")
            select_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 3px;")

            # 使用默认参数创建局部变量，确保每个按钮绑定正确的书籍
            select_btn.clicked.connect(lambda checked, b=book, btn=select_btn: self.toggle_selection(b, btn))

            # 保存按钮与书籍的映射关系
            self.book_buttons[book] = select_btn

            book_layout.addLayout(info_layout, 1)
            book_layout.addWidget(select_btn)

            # 设置边框样式
            book_widget.setStyleSheet("""
                QWidget {
                    border: 1px solid #E0E0E0;
                    border-radius: 5px;
                    padding: 5px;
                    margin: 5px;
                }
                QWidget:hover {
                    border: 1px solid #94070A;
                }
            """)

            self.books_layout.addWidget(book_widget, row, col)

            col += 1
            if col >= 2:
                col = 0
                row += 1

    def search_books(self):
        keyword = self.search_input.text().strip().lower()
        if not keyword:
            self.display_books(self.all_books)
            return

        # 搜索匹配的书籍
        result = []
        for book in self.all_books:
            if keyword in book.name.lower() or any(keyword in tag.lower() for tag in book.tag):
                result.append(book)

        self.display_books(result)

    def toggle_selection(self, book, button):
        if book in self.selected_books:
            self.selected_books.remove(book)
            button.setText("选择")
            button.setStyleSheet("background-color: #94070A; color: white; border-radius: 3px;")
        else:
            self.selected_books.append(book)
            button.setText("已选择")
            button.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 3px;")

    def add_selected_books(self):
        if not self.selected_books:
            QMessageBox.information(self, "提示", "请先选择要添加的书籍")
            return

        # 将选中的书籍添加到用户的已买入列表
        for book in self.selected_books:
            if book not in self.user.buyrecords:
                self.user.buyrecords.append(book)

        # 保存用户数据
        self.user.users_store()

        QMessageBox.information(self, "成功", f"已成功添加 {len(self.selected_books)} 本书籍到您的已买入列表")
        self.accept()

class ProfilePage(QWidget):
    """个人主页"""

    def __init__(self, user=None, parent=None):
        super().__init__(parent)
        self.user = user  # 使用User类实例
        self.stats_labels = {}  # 用于存储统计标签
        # self.initUI()

    def initUI(self):
        # 创建主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # 用户信息区域
        user_info_layout = QHBoxLayout()

        # 用户头像
        avatar_label = QLabel()
        try:
            pixmap = QPixmap("./image/头像.png")
            scaled_pixmap = pixmap.scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            avatar_label.setPixmap(scaled_pixmap)
        except:
            avatar_label.setText("头像")
        avatar_label.setFixedSize(80, 80)
        avatar_label.setStyleSheet("border-radius: 50px; border: 2px solid #1E88E5;")
        user_info_layout.addWidget(avatar_label)

        # 用户信息
        info_layout = QVBoxLayout()
        username_label = QLabel(f"用户名: {self.user.account}")
        username_label.setObjectName("username_label")  # 添加对象名称
        font = username_label.font()
        font.setBold(True)
        font.setPointSize(14)
        username_label.setFont(font)
        info_layout.addWidget(username_label)

        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(20)

        selling_count = len([book for book in self.user.sellrecords if not book.sale])
        sold_count = len([book for book in self.user.sellrecords if book.sale])
        bought_count = len(self.user.buyrecords)
        # 计算统计数据
        # selling_count = 0
        # sold_count = 0
        # bought_count = 0

        # 保存统计标签以便后续更新
        self.stats_labels["selling"] = self.add_stat_item(stats_layout, "在售中", selling_count)
        self.stats_labels["sold"] = self.add_stat_item(stats_layout, "已售出", sold_count)
        self.stats_labels["bought"] = self.add_stat_item(stats_layout, "已买入", bought_count)

        info_layout.addLayout(stats_layout)

        user_info_layout.addLayout(info_layout)

        # 编辑资料按钮
        edit_btn = QPushButton("添加已买入书籍")
        edit_btn.setFixedSize(140, 30)
        edit_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 5px;")
        edit_btn.clicked.connect(self.add_bought_books)
        user_info_layout.addWidget(edit_btn, 0, Qt.AlignRight)

        main_layout.addLayout(user_info_layout)

        # 分隔线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # 标签页
        tab_layout = QHBoxLayout()

        self.tab_buttons = []
        tabs = ["在售中", "已售出", "已买入"]
        # tabs = ["在售中", "已售出"]
        for tab in tabs:
            btn = QPushButton(tab)
            btn.setCheckable(True)
            btn.setMinimumHeight(40)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #333333;
                    border: none;
                    border-bottom: 2px solid #CCCCCC;
                }
                QPushButton:checked {
                    background-color: white;
                    color: #94070A;
                    border-bottom: 2px solid #94070A;
                }
            """)
            if tab == "在售中":
                btn.setChecked(True)
            btn.clicked.connect(lambda checked, t=tab: self.change_tab(t))
            tab_layout.addWidget(btn)
            self.tab_buttons.append(btn)

        main_layout.addLayout(tab_layout)

        # 内容区域
        self.content_area = QScrollArea()
        self.content_area.setWidgetResizable(True)
        self.content_widget = QWidget()
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_area.setWidget(self.content_widget)

        main_layout.addWidget(self.content_area, 1)

        # 初始化显示我的发布
        self.change_tab("在售中")

        # 更新统计数据（确保初始化时正确显示）
        self.update_stats()

    def add_stat_item(self, layout, title, count):
        stat_widget = QWidget()
        stat_layout = QVBoxLayout(stat_widget)
        stat_layout.setContentsMargins(0, 0, 0, 0)

        count_label = QLabel(str(count))
        count_label.setObjectName(f"{title.lower().replace(' ', '_')}_count")  # 设置对象名称
        font = count_label.font()
        font.setBold(True)
        font.setPointSize(16)
        count_label.setFont(font)
        count_label.setAlignment(Qt.AlignCenter)
        stat_layout.addWidget(count_label)

        title_label = QLabel(title)
        title_label.setAlignment(Qt.AlignCenter)
        stat_layout.addWidget(title_label)

        layout.addWidget(stat_widget)
        return count_label



    def change_tab(self, tab_name):
        # 重置所有按钮状态
        for btn in self.tab_buttons:
            btn.setChecked(False)

        # 设置当前按钮为选中状态
        for btn in self.tab_buttons:
            if btn.text() == tab_name:
                btn.setChecked(True)
                break

        # 安全清空当前内容区域，包括所有子布局
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.layout():
                # 递归清空子布局
                while item.layout().count():
                    sub_item = item.layout().takeAt(0)
                    widget = sub_item.widget()
                    if widget:
                        widget.setParent(None)
            widget = item.widget()
            if widget:
                widget.setParent(None)

        # 根据标签显示不同内容
        if tab_name == "在售中":
            self.display_my_books()
        elif tab_name == "已售出":
            self.display_sold_books()
        elif tab_name == "已买入":
            self.display_bought_books()

        # 更新统计数据（确保切换标签页时数据正确）
        self.update_stats()

    def update_user(self, user):
        """更新用户信息"""
        self.user = user
        self.initUI()
        # 更新UI元素
        if hasattr(self, 'username_label'):
            self.username_label.setText(f"用户名: {self.user.account}")
        # 更新统计数据
        self.update_stats()
        # 刷新当前显示的内容
        current_tab = next((btn.text() for btn in self.tab_buttons if btn.isChecked()), "在售中")
        self.change_tab(current_tab)
    def display_my_books(self):
        # 获取我的发布的书籍
        my_books = [book for book in self.user.sellrecords if not book.sale]

        if not my_books:
            empty_label = QLabel("您暂时没有在售的书籍")
            empty_label.setAlignment(Qt.AlignCenter)
            empty_label.setStyleSheet("color: #999999; font-size: 14px; margin-top: 50px;")
            self.content_layout.addWidget(empty_label)
            return

        # 显示书籍
        for book in my_books:
            book_item = BookItem(book)
            self.content_layout.addWidget(book_item)

            # 添加操作按钮
            action_layout = QHBoxLayout()

            edit_btn = QPushButton("编辑")
            edit_btn.setFixedSize(80, 25)
            edit_btn.setStyleSheet("background-color: #1E88E5; color: white; border-radius: 3px;")
            try:
                edit_btn.clicked.connect(lambda checked, b=book: self.edit_book(b))
            except Exception as e:
                print(e)
            action_layout.addWidget(edit_btn)

            if not book.sale:
                sell_btn = QPushButton("标记为已售出")
                sell_btn.setFixedSize(100, 25)
                sell_btn.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 3px;")
                sell_btn.clicked.connect(lambda checked, b=book: self.mark_as_sold(b))
                action_layout.addWidget(sell_btn)

            delete_btn = QPushButton("删除")
            delete_btn.setFixedSize(80, 25)
            delete_btn.setStyleSheet("background-color: #F44336; color: white; border-radius: 3px;")
            delete_btn.clicked.connect(lambda checked, b=book: self.delete_book(b))
            action_layout.addWidget(delete_btn)

            action_layout.addStretch()
            self.content_layout.addLayout(action_layout)

    def display_sold_books(self):
        sold_books = [book for book in self.user.sellrecords if book.sale]
        if not sold_books:
            empty_label = QLabel("您还没有卖出任何书籍")
            empty_label.setAlignment(Qt.AlignCenter)
            empty_label.setStyleSheet("color: #999999; font-size: 14px; margin-top: 50px;")
            self.content_layout.addWidget(empty_label)
            return

        # 显示书籍
        for book in sold_books:
            book_item = BookItem(book)
            self.content_layout.addWidget(book_item)

    def display_bought_books(self):
        # 获取已买入的书籍
        bought_books = self.user.buyrecords

        if not bought_books:
            empty_label = QLabel("您还没有买入任何书籍")
            empty_label.setAlignment(Qt.AlignCenter)
            empty_label.setStyleSheet("color: #999999; font-size: 14px; margin-top: 50px;")
            self.content_layout.addWidget(empty_label)
            return

        # 显示书籍
        for book in bought_books:
            book_item = BookItem(book)
            self.content_layout.addWidget(book_item)

    def add_bought_books(self):
        """添加已买入书籍的功能"""
        from main import books  # 导入全局的书籍列表

        # 创建并显示添加已买入书籍的对话框
        dialog = AddBoughtBookDialog(self, books, self.user)
        if dialog.exec_():
            # 更新已买入书籍列表
            self.change_tab("已买入")
            # 更新统计数据
            self.update_stats()
            self.user.users_store()

    def edit_book(self, book):
        """编辑书籍信息"""
        from PyQt5.QtWidgets import QDialog, QVBoxLayout, QGridLayout, QLabel, QLineEdit, QTextEdit, QComboBox, \
            QPushButton, QScrollArea, QWidget, QFileDialog, QMessageBox
        import os
        import uuid
        import shutil

        dialog = QDialog(self)
        dialog.setWindowTitle(f"编辑书籍: {book.name}")
        dialog.setMinimumWidth(600)
        dialog.setMinimumHeight(600)

        main_layout = QVBoxLayout(dialog)

        # 表单标题
        title_label = QLabel("编辑二手书籍")
        font = title_label.font()
        font.setBold(True)
        font.setPointSize(16)
        title_label.setFont(font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)

        # 分隔线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # 创建滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)

        # 表单布局
        form_layout = QGridLayout()
        form_layout.setSpacing(15)
        form_layout.setColumnStretch(1, 1)

        # 书名
        form_layout.addWidget(QLabel("书名:"), 0, 0)
        name_edit = QLineEdit(book.name)
        form_layout.addWidget(name_edit, 0, 1)

        # 价格
        form_layout.addWidget(QLabel("价格:"), 1, 0)
        price_edit = QLineEdit(str(book.price))
        form_layout.addWidget(price_edit, 1, 1)

        # 崭新程度
        form_layout.addWidget(QLabel("崭新程度:"), 2, 0)
        broken_combo = QComboBox()
        brokens = ["全新", "九五新", "九成新", "八五新", "八成新", "七成新及以下"]
        broken_dict={"全新":0,"九五新":1,"九成新":2,"八五新":3,"八成新":4,"七成新及以下":5}
        broken_combo.addItems(brokens)
        # 设置当前选中项
        for i, text in enumerate(brokens):
            if text == book.broken:
                broken_combo.setCurrentIndex(i)
                break
        form_layout.addWidget(broken_combo, 2, 1)

        # 图片与标签并排区域
        image_tag_layout = QHBoxLayout()

        # 上传图片（左侧）
        image_group = QGroupBox("书籍图片")
        image_group.setMinimumWidth(150)
        upload_layout = QVBoxLayout(image_group)

        image_label = QLabel()
        image_label.setFixedSize(120, 160)
        image_label.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 5px;")
        image_label.setAlignment(Qt.AlignCenter)

        # 尝试加载当前图片
        try:
            pixmap = QPixmap(book.image_path)
            scaled_pixmap = pixmap.scaled(120, 160, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            image_label.setPixmap(scaled_pixmap)
        except:
            image_label.setText("图片加载失败")

        # 存储新选择的图片路径
        new_image_path = book.image_path

        def upload_new_image():
            nonlocal new_image_path
            file_path, _ = QFileDialog.getOpenFileName(
                dialog, "选择图片", "", "图片文件 (*.png *.jpg *.jpeg *.bmp)"
            )

            if file_path:
                new_image_path = file_path
                pixmap = QPixmap(file_path)
                scaled_pixmap = pixmap.scaled(120, 160, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                image_label.setPixmap(scaled_pixmap)

        image_label.mousePressEvent = lambda event: upload_new_image()
        upload_layout.addWidget(image_label)

        upload_layout.addStretch()
        image_group.setLayout(upload_layout)
        image_tag_layout.addWidget(image_group)

        # 右侧区域（简介和标签）
        right_side_layout = QVBoxLayout()

        # 书籍简介
        desc_group = QGroupBox("书籍简介")
        desc_layout = QVBoxLayout(desc_group)

        desc_input = QTextEdit()
        desc_input.setPlainText(book.information)
        desc_input.setMinimumHeight(80)
        desc_input.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 3px;")
        desc_layout.addWidget(desc_input)

        desc_group.setLayout(desc_layout)
        right_side_layout.addWidget(desc_group)

        # 已选标签显示
        tag_group = QGroupBox("已选标签")
        tag_layout = QVBoxLayout(tag_group)

        tags_container = QWidget()
        tags_layout = QVBoxLayout(tags_container)
        tags_layout.setSpacing(5)
        tags_layout.setAlignment(Qt.AlignTop)
        tags_layout.setContentsMargins(5, 5, 5, 5)

        scroll_area_tags = QScrollArea()
        scroll_area_tags.setWidgetResizable(True)
        scroll_area_tags.setWidget(tags_container)
        scroll_area_tags.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area_tags.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area_tags.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 3px;")
        scroll_area_tags.setMinimumHeight(80)

        tag_layout.addWidget(scroll_area_tags)
        tag_group.setLayout(tag_layout)
        right_side_layout.addWidget(tag_group)

        right_side_layout.setStretch(0, 1)  # 简介占1份
        right_side_layout.setStretch(1, 1)  # 标签占1份

        image_tag_layout.addLayout(right_side_layout, 1)  # 右侧区域占满剩余空间

        form_layout.addLayout(image_tag_layout, 3, 0, 1, 2)  # 占据第3行两列

        # 标签输入与下拉区域
        form_layout.addWidget(QLabel("输入标签:"), 4, 0)

        input_layout = QHBoxLayout()
        tag_input = QLineEdit()
        tag_input.setPlaceholderText("输入标签并按回车添加")
        tag_input.setStyleSheet("border: 1px solid #CCCCCC; border-radius: 3px;")

        dropdown_btn = QPushButton("▼")
        dropdown_btn.setFixedSize(30, 35)
        dropdown_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                border: 1px solid #CCCCCC;
                border-radius: 0 3px 3px 0;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)

        input_layout.addWidget(tag_input, 1)
        input_layout.addWidget(dropdown_btn)
        form_layout.addLayout(input_layout, 4, 1)

        # 下拉标签选择区域
        dropdown_area = QWidget()
        dropdown_area.setMaximumHeight(200)
        # dropdown_area.hide()

        dropdown_layout = QGridLayout(dropdown_area)
        dropdown_layout.setSpacing(5)
        dropdown_layout.setContentsMargins(5, 5, 5, 5)

        # 添加预设标签
        preset_tags = ["编程开发", "文学小说", "历史传记", "科学技术", "心理学",
                       "经济学", "艺术设计", "教育考试", "计算机", "数学", "英语", "哲学"]

        # 当前选中的标签（初始化为书籍已有标签）
        selected_tags = book.tag.copy()

        row = 0
        col = 0
        for tag in preset_tags:
            btn = QPushButton(tag)
            btn.setCheckable(True)
            btn.setChecked(tag in selected_tags)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #333333;
                    border-radius: 5px;
                    padding: 5px 10px;
                }
                QPushButton:checked {
                    background-color: #94070A;
                    color: white;
                }
                QPushButton:hover {
                    background-color: #E0E0E0;
                }
            """)
            btn.clicked.connect(
                lambda checked, t=tag: selected_tags.append(t) if checked and t not in selected_tags else (
                    selected_tags.remove(t) if not checked and t in selected_tags else None))
            dropdown_layout.addWidget(btn, row, col)

            col += 1
            if col >= 4:
                col = 0
                row += 1

        # def toggle_dropdown():
        #     """切换下拉菜单的显示/隐藏"""
        #     if dropdown_area.isVisible():
        #         dropdown_area.hide()
        #     else:
        #         dropdown_area.show()
        #
        # dropdown_btn.clicked.connect(toggle_dropdown)

        def add_tag():
            """添加手动输入的标签"""
            tag_text = tag_input.text().strip()
            if tag_text and tag_text not in selected_tags:
                selected_tags.append(tag_text)
                update_tags_display()
                tag_input.clear()
                dropdown_area.hide()
                # 更新预设标签按钮状态
                for i in range(dropdown_layout.count()):
                    widget = dropdown_layout.itemAt(i).widget()
                    if isinstance(widget, QPushButton) and widget.isCheckable():
                        widget.setChecked(widget.text() in selected_tags)

        tag_input.returnPressed.connect(add_tag)

        def remove_tag(tag):
            """移除标签"""
            if tag in selected_tags:
                selected_tags.remove(tag)
                update_tags_display()
                # 更新预设标签按钮状态
                for i in range(dropdown_layout.count()):
                    widget = dropdown_layout.itemAt(i).widget()
                    if isinstance(widget, QPushButton) and widget.isCheckable():
                        widget.setChecked(widget.text() in selected_tags)

        def update_tags_display():
            """更新标签显示区域"""
            # 清空现有标签
            while tags_layout.count():
                item = tags_layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.setParent(None)

            # 添加所有选中的标签
            for tag in selected_tags:
                tag_widget = QWidget()
                tag_layout = QHBoxLayout(tag_widget)
                tag_layout.setContentsMargins(5, 2, 5, 2)
                tag_layout.setSpacing(5)

                tag_label = QLabel(tag)
                tag_label.setStyleSheet("color: white;")

                remove_btn = QPushButton("×")
                remove_btn.setFixedSize(20, 20)
                remove_btn.setStyleSheet("""
                    QPushButton {
                        background-color: #CC0000;
                        color: white;
                        border-radius: 10px;
                        padding: 0;
                        font-weight: bold;
                    }
                    QPushButton:hover {
                        background-color: #FF0000;
                    }
                """)
                remove_btn.clicked.connect(lambda checked, t=tag: remove_tag(t))

                tag_layout.addWidget(tag_label)
                tag_layout.addWidget(remove_btn)

                tag_widget.setStyleSheet("background-color: #94070A; border-radius: 15px;")
                tags_layout.addWidget(tag_widget)

            # 添加拉伸，使标签靠上显示
            tags_layout.addStretch()

        # 初始化标签显示
        update_tags_display()

        form_layout.addWidget(dropdown_area, 5, 0, 1, 2)
        form_layout.addWidget(QLabel("提示: 可从下拉菜单选择标签或手动输入"), 6, 0, 1, 2)

        scroll_layout.addLayout(form_layout)
        scroll_layout.addStretch()

        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area, 1)

        # 分隔线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # 提交按钮
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(20)
        btn_layout.setContentsMargins(0, 20, 0, 0)

        submit_btn = QPushButton("保存更改")
        submit_btn.setMinimumHeight(40)
        submit_btn.setStyleSheet("background-color: #94070A; color: white; border-radius: 5px; font-size: 14px;")

        def save_changes():
            # 验证表单
            name = name_edit.text().strip()
            if not name:
                QMessageBox.warning(dialog, "提示", "请输入书名")
                return

            price_text = price_edit.text().strip()
            if not price_text:
                QMessageBox.warning(dialog, "提示", "请输入价格")
                return

            try:
                price = float(price_text)
                if price <= 0:
                    raise ValueError
            except ValueError:
                QMessageBox.warning(dialog, "提示", "请输入有效的价格")
                return

            if not selected_tags:
                QMessageBox.warning(dialog, "提示", "请至少添加一个标签")
                return

            # 获取选中的崭新程度
            broken = broken_dict[broken_combo.currentText()]
            # self.broken_group.checkedId()
            # 获取书籍简介
            information = desc_input.toPlainText().strip()

            # 如果图片有更新，保存新图片
            saved_image_path = book.image_path
            if new_image_path != book.image_path:
                # 图片保存的基础目录
                IMAGE_DIR = "image"
                os.makedirs(IMAGE_DIR, exist_ok=True)

                try:
                    # 获取文件扩展名
                    file_ext = os.path.splitext(new_image_path)[1].lower()

                    # 生成唯一文件名
                    unique_filename = f"{uuid.uuid4().hex}{file_ext}"

                    # 构建保存路径
                    saved_image_path = os.path.join(IMAGE_DIR, unique_filename)

                    # 复制文件到保存路径
                    shutil.copy2(new_image_path, saved_image_path)

                except Exception as e:
                    QMessageBox.warning(dialog, "提示", f"图片保存失败: {str(e)}")
                    saved_image_path = book.image_path  # 回退到原始图片

            # 更新书籍信息
            book.name = name
            book.price = price
            book.broken = broken
            book.tag = selected_tags
            book.information = information
            book.image_path = saved_image_path

            # 保存更改
            book.save()
            self.user.users_store()

            QMessageBox.information(dialog, "成功", "书籍信息已更新")
            dialog.accept()

        submit_btn.clicked.connect(save_changes)
        btn_layout.addWidget(submit_btn)

        cancel_btn = QPushButton("取消")
        cancel_btn.setMinimumHeight(40)
        cancel_btn.setStyleSheet("background-color: #F5F5F5; color: #333333; border-radius: 5px; font-size: 14px;")
        cancel_btn.clicked.connect(dialog.reject)
        btn_layout.addWidget(cancel_btn)

        main_layout.addLayout(btn_layout)

        if dialog.exec_():
            # 刷新当前标签页
            current_tab = next((btn.text() for btn in self.tab_buttons if btn.isChecked()), "在售中")
            self.change_tab(current_tab)

    def mark_as_sold(self, book):
        # 直接更新书籍状态，无需重复添加到sellrecords
        book.sale = True

        QMessageBox.information(self, "成功", f"书籍《{book.name}》已标记为已售出")
        self.change_tab("在售中")
        book.save()
        # 更新统计数据（书籍状态从在售变为已售出）
        self.update_stats()

    def delete_book(self, book):
        reply = QMessageBox.question(
            self, "确认删除", f"确定要删除书籍《{book.name}》吗？",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            book.sale=1
            # 从销售记录中删除
            if book in self.user.sellrecords:
                self.user.sellrecords.remove(book)
            self.user.users_store()
            QMessageBox.information(self, "成功", f"书籍《{book.name}》已删除")
            self.change_tab("在售中")

            # 更新统计数据（删除书籍会影响统计）
            self.update_stats()

    def update_stats(self):
        """更新用户书籍统计数据"""
        if not self.stats_labels:
            return

        # 计算新的统计数据
        selling_count = len([book for book in self.user.sellrecords if not book.sale])
        sold_count = len([book for book in self.user.sellrecords if book.sale])
        bought_count = len(self.user.buyrecords)

        # 更新标签显示
        if "selling" in self.stats_labels:
            self.stats_labels["selling"].setText(str(selling_count))
        if "sold" in self.stats_labels:
            self.stats_labels["sold"].setText(str(sold_count))
        if "bought" in self.stats_labels:
            self.stats_labels["bought"].setText(str(bought_count))


class MainWindow(QMainWindow):
    """主窗口"""

    def __init__(self):
        super().__init__()
        self.books = books
        self.user = users[0]  # 初始用户为None
        self.initUI()

    def initUI(self):
        # 设置窗口标题和大小
        self.setWindowTitle('书香博雅图书交易系统')
        self.setGeometry(100, 100, 400, 300)
        # self.setFixedSize(1000, 700)

        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 创建主布局
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # 创建所有页面（包括登录页面）
        self.login_page = LoginWindow()
        self.login_page.login_button.clicked.connect(self.on_login_success)
        # self.login_page.go_to_mainwindow = self.on_login_success  # 重定向登录方法
        self.home_page = HomePage(self, self.books)
        self.sell_book_page = SellBookPage(self)
        self.help_page = HelpPage()
        self.profile_page = ProfilePage()   # 初始为空

        # 创建内容区域
        self.stacked_widget = QWidget()
        self.stacked_layout = QVBoxLayout(self.stacked_widget)

        # 将所有页面添加到内容区域
        self.stacked_layout.addWidget(self.login_page)
        self.stacked_layout.addWidget(self.home_page)
        self.stacked_layout.addWidget(self.sell_book_page)
        self.stacked_layout.addWidget(self.help_page)
        self.stacked_layout.addWidget(self.profile_page)

        # 创建顶部导航栏（初始隐藏，登录后显示）
        self.create_navigation_bar(main_layout)
        self.nav_bar.hide()  # 初始隐藏导航栏

        # 设置初始页面为登录页
        self.switch_page(self.login_page)

        main_layout.addWidget(self.stacked_widget, 1)

    def create_navigation_bar(self, layout):
        """创建顶部导航栏"""
        self.nav_bar = QWidget()
        self.nav_bar.setStyleSheet("background-color: #94070A; color: white; padding: 10px;")

        nav_layout = QHBoxLayout(self.nav_bar)
        nav_layout.setContentsMargins(20, 0, 20, 0)

        # 系统名称
        title_label = QLabel("书香博雅图书交易系统")
        font = title_label.font()
        font.setBold(True)
        font.setPointSize(16)
        title_label.setFont(font)
        nav_layout.addWidget(title_label)

        nav_layout.addStretch()

        # 导航按钮
        self.nav_buttons = []
        nav_items = [("首页", self.home_page), ("卖书", self.sell_book_page),
                     ("问题咨询", self.help_page), ("个人主页", self.profile_page)]

        for text, page in nav_items:
            btn = QPushButton(text)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: white;
                    border: none;
                    padding: 5px 15px;
                    font-size: 14px;
                }
                QPushButton:hover {
                    background-color: #FF070A;
                    border-radius: 5px;
                }
                QPushButton:pressed {
                    background-color: #4D070A;
                }
            """)
            btn.setMinimumHeight(35)
            btn.clicked.connect(lambda checked, p=page: self.switch_page(p))
            nav_layout.addWidget(btn)
            self.nav_buttons.append(btn)

        layout.addWidget(self.nav_bar)

    def on_login_success(self):
        """处理登录成功事件"""
        account = self.login_page.account_edit.text()
        password = self.login_page.password_edit.text()

        # 验证逻辑（保持原有代码逻辑）
        flag = 1
        for item in users:
            if account == item.account:
                flag = 0
                if password == item.password:
                    self.login_page.show_message("欢迎", "登录成功")
                    self.setFixedSize(1000,700)
                    self.user = item  # 设置当前用户
                    # 更新个人主页
                    if self.profile_page:
                        self.profile_page.update_user(self.user)
                        self.sell_book_page.user=self.user
                        self.home_page.user=self.user
                    self.switch_page(self.home_page)  # 切换到首页
                    self.nav_bar.show()  # 显示导航栏
                else:
                    self.login_page.show_message("错误", "密码错误")
        if flag == 1:
            self.login_page.show_message("错误", "账号不存在")

    def switch_page(self, page):
        """切换显示的页面"""
        # 隐藏所有页面
        for i in range(self.stacked_layout.count()):
            widget = self.stacked_layout.itemAt(i).widget()
            widget.hide()

        # 显示选中的页面
        page.show()
if __name__ == '__main__':
    # 确保中文显示正常
    import matplotlib
    matplotlib.use('Agg')
    app = QApplication(sys.argv)
    # 设置全局字体
    font = QFont("SimHei")
    app.setFont(font)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
