import numpy as np
import json as js
BOOK_FILE_PATH = "./data/Books.json"

class Book:
    def __init__(self, name, price, broken, tag, account, information, sale, image_path,id=None):
        self.id = id
        self.name = name
        self.price = price
        self.broken = broken
        self.tag = tag
        self.account = account
        self.information = information
        self.sale = sale
        self.image_path = image_path

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'broken': self.broken,
            'tag': self.tag,
            'account': self.account,
            'information': self.information,
            'sale': int(self.sale),
            'image_path': self.image_path
        }

    @staticmethod
    def from_dict(data):
        return Book(
            data['name'],
            float(data['price']),
            int(data['broken']),
            data['tag'],
            data['account'],
            data['information'],
            data['sale'],
            data['image_path'],
            data['id'],
        )

    @staticmethod
    def get_all():
        """加载所有书籍数据"""
        try:
            with open(BOOK_FILE_PATH, 'r', encoding='utf-8') as file:
                data_list = js.load(file)
                return [Book.from_dict(data) for data in data_list]
        except (FileNotFoundError, js.JSONDecodeError):
            return []

    def save(self):
        """保存当前书籍到文件"""
        books = Book.get_all()
        MAX_ID=0
        for book in books:
            if book.id>MAX_ID:
                MAX_ID=book.id
        self.id=MAX_ID+1
        books.append(self)  # 添加新书
        
        # 将所有书籍保存回文件
        with open(BOOK_FILE_PATH, 'w', encoding='utf-8') as file:
            js.dump([book.to_dict() for book in books], file, ensure_ascii=False, indent=4)

  

    def update_broken(self, broken):
        """更新书籍破损程度"""
        self.broken = broken
        self.save()

    def add_tag(self, tag):
        """添加标签"""
        if tag not in self.tag:
            self.tag.append(tag)
            self.save()



    def update_information(self, information):
        """更新书籍描述"""
        self.information = information
        self.save()

    def update_sale_status(self, sale):
        """更新销售状态"""
        self.sale = sale
        self.save()

    def recommend_price(self):
        return (0.3+(10-self.broken/25))*self.price

    def __str__(self):
        """显示图书信息"""
        s=(f"编号：{self.id},书名：{self.name};价格：{self.price},状态：{self.broken},标签：{self.tag},发布账户：{self.account}\
           ,信息：{self.information},是否卖出：{self.sale}")
        return s
def dict_to_book(item):
    book =Book(item['name'],item['price'],item['broken'],item['tag']
               ,item['account'],item['information'],item['sale'],item['image_path'],item['id'])
    return book